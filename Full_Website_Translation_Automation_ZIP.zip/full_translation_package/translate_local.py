
from transformers import MarianMTModel, MarianTokenizer
import glob, os

LANG_MODELS = {
    "en": "Helsinki-NLP/opus-mt-fr-en",
    "de": "Helsinki-NLP/opus-mt-fr-de",
    "it": "Helsinki-NLP/opus-mt-fr-it",
    "es": "Helsinki-NLP/opus-mt-fr-es"
}

MAX_LEN = 500

def load_model(lang):
    tok = MarianTokenizer.from_pretrained(LANG_MODELS[lang])
    mod = MarianMTModel.from_pretrained(LANG_MODELS[lang])
    return tok, mod

def chunk(text):
    words = text.split()
    out, cur = [], []
    count = 0
    for w in words:
        if count + len(w) > MAX_LEN:
            out.append(" ".join(cur)); cur = []; count = 0
        cur.append(w); count += len(w)
    if cur: out.append(" ".join(cur))
    return out

def translate_file(path, lang, outfolder):
    with open(path, "r", encoding="utf-8") as f: text = f.read()
    chunks = chunk(text)
    tok, mod = load_model(lang)
    out = []
    for c in chunks:
        enc = tok(c, return_tensors="pt", padding=True, truncation=True)
        gen = mod.generate(**enc)
        out.append(tok.decode(gen[0], skip_special_tokens=True))
    fname = os.path.basename(path)
    with open(os.path.join(outfolder, fname), "w", encoding="utf-8") as f:
        f.write("
".join(out))

if __name__ == "__main__":
    src = "website_extracted"; base = "translations"
    os.makedirs(base, exist_ok=True)
    for lang in LANG_MODELS:
        outfolder = os.path.join(base, lang)
        os.makedirs(outfolder, exist_ok=True)
        for file in glob.glob(f"{src}/*.txt"):
            print(f"Translating {file} to {lang}...")
            translate_file(file, lang, outfolder)
    print("✅ Translations complete.")
