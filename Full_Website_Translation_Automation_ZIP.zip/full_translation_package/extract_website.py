
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import os, re

START_URL = "https://cyberforgood.org/fr/"
OUTPUT_FOLDER = "website_extracted"
visited = set()
EXCLUDE_TAGS = ["script", "style", "noscript", "meta", "link"]

def clean_text(soup):
    for tag in soup(EXCLUDE_TAGS): tag.extract()
    t = soup.get_text(separator="
")
    return re.sub(r"
+", "
", t).strip()

def extract_alt_texts(soup):
    alts = []
    for img in soup.find_all("img"):
        if img.get("alt"): alts.append("IMAGE_ALT: " + img.get("alt"))
    return "
".join(alts)

def crawl(url):
    if url in visited: return
    visited.add(url)
    try:
        r = requests.get(url, timeout=10)
        soup = BeautifulSoup(r.text, "html5lib")
        visible = clean_text(soup)
        alt = extract_alt_texts(soup)
        txt = visible + "

" + alt
        path = urlparse(url).path.strip("/")
        filename = "index" if not path else path.replace("/", "_")
        filepath = os.path.join(OUTPUT_FOLDER, f"{filename}.txt")
        with open(filepath, "w", encoding="utf-8") as f: f.write(txt)
        for link in soup.find_all("a", href=True):
            href = urljoin(url, link['href'])
            if START_URL in href: crawl(href)
    except Exception as e: print("Error:", e)

if __name__ == "__main__":
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    crawl(START_URL)
    print("✅ Extraction complete.")
