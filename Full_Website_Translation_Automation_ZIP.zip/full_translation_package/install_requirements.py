
import os
print('Installing all dependencies...')
os.system("pip install requests beautifulsoup4 transformers sentencepiece torch html5lib")
print('✅ Installation complete.')
